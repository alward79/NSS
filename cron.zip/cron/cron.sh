#!/bin/bash
cd ~
mv file1.txt /home/angelena/cron
echo "File has been moved to cron folder"
